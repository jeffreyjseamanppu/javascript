**SunFresh-API** is an API that will communicate with the backend database. This will allow the wineapp main application to be able retrieve data, save and modify existing data within the application

## Current Version
1.1.1

## Libraries used

#### [Libraries](http://nuget.org/packages/toastr)
```
NodeJS
JavaScript
```

## Create Initial Environment 

#### [Create Initial Environment](http://nuget.org/packages/toastr)
```
npm init --y
npm i --save express
npm i pg
```

