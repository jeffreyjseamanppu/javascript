insert into shipmentdetail
()





select
a.shipment_id,
b.shipment_detail_id,
b.shipment_hdr_id,
b.qty,
b.productid,
b.unitcost,
b.totalcost,
b.received
FROM
shipments a
JOIN
shipment_detail b
on a.shipment_id = b.shipment_detail_id