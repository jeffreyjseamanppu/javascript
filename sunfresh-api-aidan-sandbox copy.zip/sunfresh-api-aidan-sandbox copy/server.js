const express = require("express");
const shipmentdetRoutes = require("./src/shipments_det/routes");
const inventoryRoutes = require("./src/inventory/routes");
const customerRoutes = require("./src/customers/routes");
const priceRoutes = require("./src/price/routes");
const shipmentmainRoutes = require("./src/shipment_main/routes");

const app = express();
const port = 3008;

app.use(express.json());


app.get("/", (req, res) => {
    res.send("hello api world");
})

app.use("/api/v1/inventory", inventoryRoutes);
app.use("/api/v1/shipment_det", shipmentdetRoutes);
app.use("/api/v1/customers", customerRoutes)
app.use("/api/v1/price", priceRoutes)
app.use("/api/v1/shipment_main", shipmentmainRoutes)
app.listen(port, () => console.log('running ${port}'));

