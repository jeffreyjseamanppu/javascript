//Database configuration

const Pool = require("pg").Pool;

const pool = new Pool({
    user: "postgres",
    host: "localhost",
    password: "Jmdand2023!",
    database: "wine_cqrl",
    port: 5432,
});

module.exports = pool;