const pool = require('../../db');
const queries = require('./queries');

const getCustomers = "SELECT * FROM customers";
const addCustomers = "INSERT INTO customers(customers_id, first_name, last_name, address1, address2, city, state, zip, home_phone, mobile_phone, bus_phone, fax, notes, tax_exempt, order_id, item_name, item_code, status, email, qty) VALUES($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20)";
const updateCustomers = "update customers set customers_id = $1, first_name = $2, last_name = $3, address1 = $4, address2 = $5, city = $6, state = $7, zip = $8, home_phone = $9, mobile_phone = $10, bus_phone = $11, fax = $12, notes = $13, tax_exempt = $14, order_id = $15, item_name = $16, item_code = $17, status = $18, email = $19, qty = $20";


module.exports = {
    getCustomers,
    addCustomers,
    updateCustomers,
};

/*
const getShipmentdetail = (req, res) => {
    pool.query(queries.getShipmentdetail, (error, results)=> {
        if(error) throw error;
        res.status(200).json(results.rows);
    });
};
*/
