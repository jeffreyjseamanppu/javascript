const pool = require('../../db');

const getCustomers = (req, res) => {
    pool.query("SELECT * FROM customers",(error, results) => {
        if(error) throw error;
        res.status(200).json(results.rows);
    })};
    const addCustomers=(req, res) => {
        const{customers_id, first_name, last_name, address1, address2, city, state, zip, home_phone, mobile_phone, bus_phone, fax, notes, tax_exempt, order_id, item_name, item_code, status, email, qty}
     =req.body;
     

};

module.exports = {
    getCustomers,
    addCustomers
};