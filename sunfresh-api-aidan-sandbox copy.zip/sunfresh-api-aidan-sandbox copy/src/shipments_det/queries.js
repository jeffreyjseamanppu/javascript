const pool = require('../../db');
const queries = require('./queries');

//const getShipmentDetail = "SELECT * FROM shipments";
const getShipmentById = "SELECT * FROM shipments WHERE id = $1";
const checkShipmentDetail = "SELECT b FROM shipments b WHERE b.shipment_id = $1";
const addShipmentDetail = 
  "INSERT INTO shipments (name,email,age) VALUES ($1, $2, $3)";
const updateShipmentDetail =
  "UPDATE shipments set name = $1 where id = $2";  

module.exports = {
  //  getShipmentDetail,
    getShipmentById,
    checkShipmentDetail,
    addShipmentDetail,
    updateShipmentDetail,
};

/*
const getShipmentdetail = (req, res) => {
    pool.query(queries.getShipmentdetail, (error, results)=> {
        if(error) throw error;
        res.status(200).json(results.rows);
    });
};
*/
