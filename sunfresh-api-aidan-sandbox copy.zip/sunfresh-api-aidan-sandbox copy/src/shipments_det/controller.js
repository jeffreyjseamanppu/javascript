const pool = require('../../db');

const getShipmentDetail = (req, res) => {
    pool.query("SELECT * FROM shipmentdetail",(error, results) => {
        if(error) throw error;
        res.status(200).json(results.rows);
    }
    
    );
};

module.exports = {
    getShipmentDetail,
};