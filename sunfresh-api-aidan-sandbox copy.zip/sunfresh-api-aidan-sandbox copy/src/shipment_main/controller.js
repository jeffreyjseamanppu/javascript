const pool = require('../../db');

const getShipmentMain = (req, res) => {
    pool.query("SELECT * FROM shipments",(error, results) => {
        if(error) throw error;
        res.status(200).json(results.rows);
    })};
    const addShipments=(req, res) => {
        const{shipment_id, load_date, ship_date, arrival_date, status, carrier, date_revised, notes, date_entered, carrier_id}
     =req.body;
     

};

module.exports = {
    getShipmentMain,
    addShipments
};