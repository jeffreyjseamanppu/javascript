const pool = require('../../db');
const queries = require('./queries');

const getShipments = "SELECT * FROM shipments";
const addShipments = "INSERT INTO shipments(shipment_id, load_date, ship_date, arrival_date, status, carrier, date_revised, notes, date_entered, carrier_id) VALUES($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)";
const updateShipments = "update shipments set shipment_id = $1, load_date = $2, ship_date = $3, arrival_date = $4, status = $5, carrier = $6, date_revised = $7, notes = $8, date_entered = $9, carrier_id = $10";


module.exports = {
    getShipments,
    addShipments,
    updateShipments,
};

/*
const getShipmentdetail = (req, res) => {
    pool.query(queries.getShipmentdetail, (error, results)=> {
        if(error) throw error;
        res.status(200).json(results.rows);
    });
};
*/
