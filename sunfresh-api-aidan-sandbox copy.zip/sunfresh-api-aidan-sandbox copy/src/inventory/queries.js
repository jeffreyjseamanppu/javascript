const pool = require('../../db');
const queries = require('./queries');

const getInventory = "SELECT * FROM inventory";
const addInventory = "INSERT INTO inventory(description,item_code,price,qty,product_id,product_name) VALUES($1, $2, $3, $4, $5, $6)";
const updateInventory = "update inventory set description = $1, item_code = $2, price = $3, qty = $4, product_name = $5 where product_id = $6";


module.exports = {
    getInventory,
    addInventory,
    updateInventory,
};

/*
const getShipmentdetail = (req, res) => {
    pool.query(queries.getShipmentdetail, (error, results)=> {
        if(error) throw error;
        res.status(200).json(results.rows);
    });
};
*/
