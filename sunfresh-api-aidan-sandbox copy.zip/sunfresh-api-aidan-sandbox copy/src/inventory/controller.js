const pool = require('../../db');

const getInventory = (req, res) => {
    pool.query("SELECT * FROM inventory",(error, results) => {
        if(error) throw error;
        res.status(200).json(results.rows);
    })};
    const addInventory=(req, res) => {
        const{description, item_code, price, qty, product_id, product_name}
     =req.body;
     

};

module.exports = {
    getInventory,
    addInventory
};