const pool = require('../../db');
const queries = require('./queries');

const getPrice = "SELECT * FROM price";
const addPrice = "INSERT INTO price(price_key, price_id, user_id, product_id, dollars) VALUES($1, $2, $3, $4, $5)";
const updatePrice = "update price set price_key = $1, price_id = $2, user_id = $3, product_id = $4, dollars = $5";


module.exports = {
    getPrice,
    addPrice,
    updatePrice,
};

/*
const getShipmentdetail = (req, res) => {
    pool.query(queries.getShipmentdetail, (error, results)=> {
        if(error) throw error;
        res.status(200).json(results.rows);
    });
};
*/
